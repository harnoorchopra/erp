---
name: design-taste-frontend
description: "Use when building high-agency frontend interfaces with strict design taste, calibrated color, responsive layout, and motion rules — scaled to run cleanly from low-end devices to high-end ones at real traffic volume."
category: frontend
risk: safe
source: community
source_repo: Leonxlnx/taste-skill
source_type: community
date_added: "2026-04-17"
author: Leonxlnx
tags: [frontend, design, ui, react, performance]
tools: [claude, cursor, codex, antigravity]
---

# High-Agency Frontend Skill

## When to Use

- Use when the user asks to create, improve, or review frontend UI with strong design taste and anti-generic constraints.
- Use when React, Next.js, Tailwind, motion, component states, typography, spacing, color, or responsive behavior need senior-level design judgment.
- Use when the output must override common LLM UI biases such as centered heroes, purple gradients, card overuse, poor states, and fragile layouts.
- Use for any interface that will be shipped to real traffic — the motion and effects rules below are paired with a device-tier system so the same interface stays smooth on a budget phone and impressive on a high-end one.

## Limitations

- This skill provides frontend design and implementation guidance; it does not replace project-specific product requirements, accessibility review, or user testing.
- Verify framework versions, installed dependencies, responsive behavior, and build output in the target repository before treating generated UI as production-ready.
- Do not force these design rules when the existing product, brand system, or platform conventions require a different visual direction.
- Device-tier detection (Section 1B) is a heuristic, not a guarantee — always pair it with `prefers-reduced-motion` and manual QA on a real low-end device or a throttled emulator, not just the JS signals.

## 1. ACTIVE BASELINE CONFIGURATION

- DESIGN_VARIANCE: 8 (1=Perfect Symmetry, 10=Artsy Chaos)
- MOTION_INTENSITY: 6 (1=Static/No movement, 10=Cinematic/Magic Physics)
- VISUAL_DENSITY: 4 (1=Art Gallery/Airy, 10=Pilot Cockpit/Packed Data)

**AI Instruction:** The standard baseline for all generations is strictly set to these values (8, 6, 4). Do not ask the user to edit this file. Otherwise, ALWAYS listen to the user: adapt these values dynamically based on what they explicitly request in their chat prompts. Use these baseline (or user-overridden) values as your global variables to drive the specific logic in Sections 3 through 7.

**Important:** MOTION*INTENSITY is the \_design intent* — how much motion the interface is designed to have at its fullest. It is not the same as what every visitor's device actually plays. Section 1B below determines what fraction of that intent renders per visitor.

## 1B. DEVICE TIER (Automatic — Not a User Dial)

MOTION*INTENSITY and the perpetual-motion features in Sections 4 and 9 describe the \_ceiling* of the experience. At real traffic volume, a meaningful share of visitors are on a low-end Android phone, an older laptop, a throttled connection, or have `prefers-reduced-motion` set — designing only for the developer's machine means a large slice of users get jank instead of "premium."

Every component that uses continuous/perpetual motion (infinite loops, parallax, magnetic cursor-follow, GSAP/ThreeJS scenes) MUST render one of three tiers, decided once per session and reused everywhere rather than re-checked per component:

- **FULL** — capable device, no reduced-motion preference, good connection. Ship the complete MOTION_INTENSITY-level experience as designed.
- **CORE** — mid-range or unknown device. Keep CSS transitions, hover/active feedback, and load-in fades. Drop infinite/perpetual loops, parallax, and physics-based cursor-follow effects — replace them with a single static or one-shot version (e.g., a magnetic button becomes a normal `:hover` scale; an infinite carousel becomes a swipeable static row).
- **MINIMAL** — low-end device, slow connection, `prefers-reduced-motion: reduce`, or `navigator.connection.saveData`. Instant state changes only (checkmarks, toggles, page content) with fades under 150ms or no transition at all. No decorative motion at all.

**Detection (client-side, run once and cache in a context/store — do not re-run per component):**

```javascript
function getDeviceTier() {
  if (typeof window === "undefined") return "CORE"; // SSR-safe default

  const reducedMotion = window.matchMedia(
    "(prefers-reduced-motion: reduce)",
  ).matches;
  if (reducedMotion) return "MINIMAL";

  const memory = navigator.deviceMemory; // GB, undefined on unsupported browsers
  const cores = navigator.hardwareConcurrency;
  const conn = navigator.connection;
  const saveData = conn?.saveData;
  const slowNetwork =
    conn?.effectiveType && ["slow-2g", "2g", "3g"].includes(conn.effectiveType);

  if (
    saveData ||
    slowNetwork ||
    (memory && memory <= 2) ||
    (cores && cores <= 4)
  ) {
    return "MINIMAL";
  }
  if ((memory && memory < 8) || (cores && cores < 8) || memory === undefined) {
    return "CORE"; // unsupported/uncertain signals default to the safe middle tier
  }
  return "FULL";
}
```

- Treat missing API support (Safari doesn't expose `deviceMemory`) as CORE, never as FULL — never let an unsupported API silently grant the heaviest experience.
- `prefers-reduced-motion` always wins regardless of hardware signals — it's a stated preference, not a guess.
- Heavy libraries (GSAP, Three.js, full Framer Motion feature set) should be lazy-loaded (`React.lazy`/dynamic `import()`) and the import itself should be skipped entirely on MINIMAL — don't ship the bytes for motion the user will never see.

## 2. DEFAULT ARCHITECTURE & CONVENTIONS

Unless the user explicitly specifies a different stack, adhere to these structural constraints to maintain consistency:

- **DEPENDENCY VERIFICATION [MANDATORY]:** Before importing ANY 3rd party library (e.g. `framer-motion`, `lucide-react`, `zustand`), you MUST check `package.json`. If the package is missing, you MUST output the installation command (e.g. `npm install package-name`) before providing the code. **Never** assume a library exists.
- **Framework & Interactivity:** React or Next.js. Default to Server Components (`RSC`).
  - **RSC SAFETY:** Global state works ONLY in Client Components. In Next.js, wrap providers in a `"use client"` component.
  - **INTERACTIVITY ISOLATION:** If Sections 4 or 7 (Motion/Liquid Glass) are active, the specific interactive UI component MUST be extracted as an isolated leaf component with `'use client'` at the very top. Server Components must exclusively render static layouts.
- **State Management:** Use local `useState`/`useReducer` for isolated UI. Use global state strictly for deep prop-drilling avoidance.
- **Styling Policy:** Use Tailwind CSS (v3/v4) for 90% of styling.
  - **TAILWIND VERSION LOCK:** Check `package.json` first. Do not use v4 syntax in v3 projects.
  - **T4 CONFIG GUARD:** For v4, do NOT use `tailwindcss` plugin in `postcss.config.js`. Use `@tailwindcss/postcss` or the Vite plugin.
- **ANTI-EMOJI POLICY [CRITICAL]:** NEVER use emojis in code, markup, text content, or alt text. Replace symbols with high-quality icons (Radix, Phosphor) or clean SVG primitives. Emojis are BANNED.
- **Responsiveness & Spacing:**
  - Standardize breakpoints (`sm`, `md`, `lg`, `xl`).
  - Contain page layouts using `max-w-[1400px] mx-auto` or `max-w-7xl`.
  - **Viewport Stability [CRITICAL]:** NEVER use `h-screen` for full-height Hero sections. ALWAYS use `min-h-[100dvh]` to prevent catastrophic layout jumping on mobile browsers (iOS Safari).
  - **Grid over Flex-Math:** NEVER use complex flexbox percentage math (`w-[calc(33%-1rem)]`). ALWAYS use CSS Grid (`grid grid-cols-1 md:grid-cols-3 gap-6`) for reliable structures.
- **Icons:** You MUST use exactly `@phosphor-icons/react` or `@radix-ui/react-icons` as the import paths (check installed version). Standardize `strokeWidth` globally (e.g., exclusively use `1.5` or `2.0`).
- **Bundle discipline at scale:** Any library used only for motion (GSAP, ThreeJS, the animation-heavy parts of Framer Motion) must be code-split behind `next/dynamic` or `React.lazy`, not imported at the top of a shared layout — a component that only 20% of visitors' devices will actually animate shouldn't cost the other 80% load time.

## 3. DESIGN ENGINEERING DIRECTIVES (Bias Correction)

LLMs have statistical biases toward specific UI cliché patterns. Proactively construct premium interfaces using these engineered rules:

**Rule 1: Deterministic Typography**

- **Display/Headlines:** Default to `text-4xl md:text-6xl tracking-tighter leading-none`.
  - **ANTI-SLOP:** Discourage `Inter` for "Premium" or "Creative" vibes. Force unique character using `Geist`, `Outfit`, `Cabinet Grotesk`, or `Satoshi`.
  - **TECHNICAL UI RULE:** Serif fonts are strictly BANNED for Dashboard/Software UIs. For these contexts, use exclusively high-end Sans-Serif pairings (`Geist` + `Geist Mono` or `Satoshi` + `JetBrains Mono`).
- **Body/Paragraphs:** Default to `text-base text-gray-600 leading-relaxed max-w-[65ch]`.
- **Font loading at scale:** Self-host variable fonts with `font-display: swap` and subset to the character set actually used — a custom display font shouldn't block first paint for every visitor to save 2kb of unused glyphs.

**Rule 2: Color Calibration**

- **Constraint:** Max 1 Accent Color. Saturation < 80%.
- **THE LILA BAN:** The "AI Purple/Blue" aesthetic is strictly BANNED. No purple button glows, no neon gradients. Use absolute neutral bases (Zinc/Slate) with high-contrast, singular accents (e.g. Emerald, Electric Blue, or Deep Rose).
- **COLOR CONSISTENCY:** Stick to one palette for the entire output. Do not fluctuate between warm and cool grays within the same project.

**Rule 3: Layout Diversification**

- **ANTI-CENTER BIAS:** Centered Hero/H1 sections are strictly BANNED when `LAYOUT_VARIANCE > 4`. Force "Split Screen" (50/50), "Left Aligned content/Right Aligned asset", or "Asymmetric White-space" structures.

**Rule 4: Materiality, Shadows, and "Anti-Card Overuse"**

- **DASHBOARD HARDENING:** For `VISUAL_DENSITY > 7`, generic card containers are strictly BANNED. Use logic-grouping via `border-t`, `divide-y`, or purely negative space. Data metrics should breathe without being boxed in unless elevation (z-index) is functionally required.
- **Execution:** Use cards ONLY when elevation communicates hierarchy. When a shadow is used, tint it to the background hue.

**Rule 5: Interactive UI States**

- **Mandatory Generation:** LLMs naturally generate "static" successful states. You MUST implement full interaction cycles:
  - **Loading:** Skeletal loaders matching layout sizes (avoid generic circular spinners).
  - **Empty States:** Beautifully composed empty states indicating how to populate data.
  - **Error States:** Clear, inline error reporting (e.g., forms).
  - **Tactile Feedback:** On `:active`, use `-translate-y-[1px]` or `scale-[0.98]` to simulate a physical push indicating success/action. This is cheap (transform-only) and should render at every device tier, including MINIMAL.

**Rule 6: Data & Form Patterns**

- **Forms:** Label MUST sit above input. Helper text is optional but should exist in markup. Error text below input. Use a standard `gap-2` for input blocks.

## 4. CREATIVE PROACTIVITY (Anti-Slop Implementation)

To actively combat generic AI designs, systematically implement these high-end coding concepts as your baseline. **Every effect in this section is a FULL-tier feature — each one needs the CORE/MINIMAL fallback described in Section 1B, not just a `prefers-reduced-motion` wrapper as an afterthought.**

- **"Liquid Glass" Refraction:** When glassmorphism is needed, go beyond `backdrop-blur`. Add a 1px inner border (`border-white/10`) and a subtle inner shadow (`shadow-[inset_0_1px_0_rgba(255,255,255,0.1)]`) to simulate physical edge refraction. `backdrop-blur` is GPU-costly at scroll time on low-end devices — on CORE/MINIMAL, swap to a flat semi-transparent fill with no blur.
- **Magnetic Micro-physics (If MOTION_INTENSITY > 5 and tier is FULL):** Implement buttons that pull slightly toward the mouse cursor. **CRITICAL:** NEVER use React `useState` for magnetic hover or continuous animations. Use EXCLUSIVELY Framer Motion's `useMotionValue` and `useTransform` outside the React render cycle to prevent performance collapse on mobile. On CORE/MINIMAL, this becomes a plain `:hover` `scale-[1.02]` — no cursor tracking.
- **Perpetual Micro-Interactions:** When `MOTION_INTENSITY > 5` and tier is FULL, embed continuous, infinite micro-animations (Pulse, Typewriter, Float, Shimmer, Carousel) in standard components (avatars, status dots, backgrounds). Apply premium Spring Physics (`type: "spring", stiffness: 100, damping: 20`) to all interactive elements—no linear easing. **Cap concurrent infinite loops per screen** (roughly 3–5 depending on complexity) even on FULL — a screen where everything pulses at once reads as noisy, not alive, and burns battery for no added clarity. On CORE, keep the shimmer/skeleton loaders only (they communicate state, not decoration) and drop purely decorative loops (floating avatars, pulsing dots with no meaning). On MINIMAL, none of these run.
- **Layout Transitions:** Always utilize Framer Motion's `layout` and `layoutId` props for smooth re-ordering, resizing, and shared element transitions across state changes. On MINIMAL, these can degrade to an instant re-render — the data still needs to update correctly, just without the animated transition.
- **Staggered Orchestration:** Do not mount lists or grids instantly. Use `staggerChildren` (Framer) or CSS cascade (`animation-delay: calc(var(--index) * 100ms)`) to create sequential waterfall reveals. **CRITICAL:** For `staggerChildren`, the Parent (`variants`) and Children MUST reside in the identical Client Component tree. If data is fetched asynchronously, pass the data as props into a centralized Parent Motion wrapper. Cap stagger to the first ~10–12 visible items in a long list — staggering fifty items in a row just delays when the last ones become visible.

## 5. PERFORMANCE GUARDRAILS

- **Device tiering is mandatory, not optional.** Every component built under Section 4 or Section 9 must branch on the tier from Section 1B — a component that only has a "full" implementation is incomplete, not just unoptimized.
- **Animate only visible content.** Wrap perpetual-motion and scroll-triggered components in an `IntersectionObserver` (or the framework's viewport hook) and pause/unmount the animation when off-screen — an infinite loop animating behind a modal or below the fold wastes CPU for nothing anyone sees.
- **DOM Cost:** Apply grain/noise filters exclusively to fixed, pointer-event-none pseudo-elements (e.g., `fixed inset-0 z-50 pointer-events-none`) and NEVER to scrolling containers to prevent continuous GPU repaints and mobile performance degradation.
- **Hardware Acceleration:** Never animate `top`, `left`, `width`, or `height`. Animate exclusively via `transform` and `opacity`.
- **Z-Index Restraint:** NEVER spam arbitrary `z-50` or `z-10` unprompted. Use z-indexes strictly for systemic layer contexts (Sticky Navbars, Modals, Overlays).
- **Test throttled, not just on your machine.** Before treating a motion-heavy component as done, check it under CPU throttling (4x–6x in browser dev tools) — this approximates the CORE/MINIMAL experience most of the actual traffic will get.

## 6. TECHNICAL REFERENCE (Dial Definitions)

### DESIGN_VARIANCE (Level 1-10)

- **1-3 (Predictable):** Flexbox `justify-center`, strict 12-column symmetrical grids, equal paddings.
- **4-7 (Offset):** Use `margin-top: -2rem` overlapping, varied image aspect ratios (e.g., 4:3 next to 16:9), left-aligned headers over center-aligned data.
- **8-10 (Asymmetric):** Masonry layouts, CSS Grid with fractional units (e.g., `grid-template-columns: 2fr 1fr 1fr`), massive empty zones (`padding-left: 20vw`).
- **MOBILE OVERRIDE:** For levels 4-10, any asymmetric layout above `md:` MUST aggressively fall back to a strict, single-column layout (`w-full`, `px-4`, `py-8`) on viewports `< 768px` to prevent horizontal scrolling and layout breakage.

### MOTION_INTENSITY (Level 1-10)

This dial sets the FULL-tier ceiling only. CORE and MINIMAL always degrade per Section 1B regardless of the number chosen here.

- **1-3 (Static):** No automatic animations. CSS `:hover` and `:active` states only. Identical across all device tiers — nothing here is expensive enough to need degrading.
- **4-7 (Fluid CSS):** Use `transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1)` — actually list the specific properties rather than `all`. Use `animation-delay` cascades for load-ins. Focus strictly on `transform` and `opacity`. Use `will-change: transform` sparingly, and only on elements about to animate. On CORE this tier is largely unchanged (CSS transitions are cheap); on MINIMAL, load-in cascades collapse to an instant appearance.
- **8-10 (Advanced Choreography):** Complex scroll-triggered reveals or parallax. Use Framer Motion hooks. NEVER use `window.addEventListener('scroll')` — use a library's scroll hook or `IntersectionObserver` so scroll handling doesn't run unthrottled on the main thread. This tier is FULL-only by definition; CORE gets simple fades in place of parallax/scroll-choreography, MINIMAL gets static content.

### VISUAL_DENSITY (Level 1-10)

- **1-3 (Art Gallery Mode):** Lots of white space. Huge section gaps. Everything feels very expensive and clean.
- **4-7 (Daily App Mode):** Normal spacing for standard web apps.
- **8-10 (Cockpit Mode):** Tiny paddings. No card boxes; just 1px lines to separate data. Everything is packed. **Mandatory:** Use Monospace (`font-mono`) for all numbers. At high density with many data rows, virtualize long lists/tables (render only visible rows) rather than mounting hundreds of DOM nodes — this matters more as density goes up, since a packed cockpit UI is usually also a high-row-count one.

## 7. AI TELLS (Forbidden Patterns)

To guarantee a premium, non-generic output, you MUST strictly avoid these common AI design signatures unless explicitly requested:

### Visual & CSS

- **NO Neon/Outer Glows:** Do not use default `box-shadow` glows or auto-glows. Use inner borders or subtle tinted shadows.
- **NO Pure Black:** Never use `#000000`. Use Off-Black, Zinc-950, or Charcoal.
- **NO Oversaturated Accents:** Desaturate accents to blend elegantly with neutrals.
- **NO Excessive Gradient Text:** Do not use text-fill gradients for large headers.
- **NO Custom Mouse Cursors:** They are outdated and ruin performance/accessibility.

### Typography

- **NO Inter Font:** Banned. Use `Geist`, `Outfit`, `Cabinet Grotesk`, or `Satoshi`.
- **NO Oversized H1s:** The first heading should not scream. Control hierarchy with weight and color, not just massive scale.
- **Serif Constraints:** Use Serif fonts ONLY for creative/editorial designs. **NEVER** use Serif on clean Dashboards.

### Layout & Spacing

- **Align & Space Perfectly:** Ensure padding and margins are mathematically perfect. Avoid floating elements with awkward gaps.
- **NO 3-Column Card Layouts:** The generic "3 equal cards horizontally" feature row is BANNED. Use a 2-column Zig-Zag, asymmetric grid, or horizontal scrolling approach instead.

### Content & Data (The "Jane Doe" Effect)

- **NO Generic Names:** "John Doe", "Sarah Chan", or "Jack Su" are banned. Use highly creative, realistic-sounding names.
- **NO Generic Avatars:** DO NOT use standard SVG "egg" or Lucide user icons for avatars. Use creative, believable photo placeholders or specific styling.
- **NO Fake Numbers:** Avoid predictable outputs like `99.99%`, `50%`, or basic phone numbers (`1234567`). Use organic, messy data (`47.2%`, `+1 (312) 847-1928`).
- **NO Startup Slop Names:** "Acme", "Nexus", "SmartFlow". Invent premium, contextual brand names.
- **NO Filler Words:** Avoid AI copywriting clichés like "Elevate", "Seamless", "Unleash", or "Next-Gen". Use concrete verbs.

### External Resources & Components

- **NO Broken Unsplash Links:** Do not use Unsplash. Use absolute, reliable placeholders like `https://picsum.photos/seed/{random_string}/800/600` or SVG UI Avatars.
- **shadcn/ui Customization:** You may use `shadcn/ui`, but NEVER in its generic default state. You MUST customize the radii, colors, and shadows to match the high-end project aesthetic.
- **Production-Ready Cleanliness:** Code must be extremely clean, visually striking, memorable, and meticulously refined in every detail.

## 8. THE CREATIVE ARSENAL (High-End Inspiration)

Do not default to generic UI. Pull from this library of advanced concepts to ensure the output is visually striking and memorable. When appropriate, leverage **GSAP (ScrollTrigger/Parallax)** for complex scrolltelling or **ThreeJS/WebGL** for 3D/Canvas animations, rather than basic CSS motion. **CRITICAL:** Never mix GSAP/ThreeJS with Framer Motion in the same component tree. Default to Framer Motion for UI/Bento interactions. Use GSAP/ThreeJS EXCLUSIVELY for isolated full-page scrolltelling or canvas backgrounds, wrapped in strict useEffect cleanup blocks. **All entries below are FULL-tier only** — on CORE, replace with the closest static/CSS equivalent (e.g., a static gallery grid instead of a 3D dome); on MINIMAL, replace with the plainest usable layout (e.g., a simple stacked list). Never ship a GSAP or ThreeJS bundle to a MINIMAL-tier visitor.

### The Standard Hero Paradigm

- Stop doing centered text over a dark image. Try asymmetric Hero sections: Text cleanly aligned to the left or right. The background should feature a high-quality, relevant image with a subtle stylistic fade (darkening or lightening gracefully into the background color depending on if it is Light or Dark mode).

### Navigation & Menüs

- **Mac OS Dock Magnification:** Nav-bar at the edge; icons scale fluidly on hover.
- **Magnetic Button:** Buttons that physically pull toward the cursor.
- **Gooey Menu:** Sub-items detach from the main button like a viscous liquid.
- **Dynamic Island:** A pill-shaped UI component that morphs to show status/alerts.
- **Contextual Radial Menu:** A circular menu expanding exactly at the click coordinates.
- **Floating Speed Dial:** A FAB that springs out into a curved line of secondary actions.
- **Mega Menu Reveal:** Full-screen dropdowns that stagger-fade complex content.

### Layout & Grids

- **Bento Grid:** Asymmetric, tile-based grouping (e.g., Apple Control Center).
- **Masonry Layout:** Staggered grid without fixed row heights (e.g., Pinterest).
- **Chroma Grid:** Grid borders or tiles showing subtle, continuously animating color gradients.
- **Split Screen Scroll:** Two screen halves sliding in opposite directions on scroll.
- **Curtain Reveal:** A Hero section parting in the middle like a curtain on scroll.

### Cards & Containers

- **Parallax Tilt Card:** A 3D-tilting card tracking the mouse coordinates.
- **Spotlight Border Card:** Card borders that illuminate dynamically under the cursor.
- **Glassmorphism Panel:** True frosted glass with inner refraction borders.
- **Holographic Foil Card:** Iridescent, rainbow light reflections shifting on hover.
- **Tinder Swipe Stack:** A physical stack of cards the user can swipe away.
- **Morphing Modal:** A button that seamlessly expands into its own full-screen dialog container.

### Scroll-Animations

- **Sticky Scroll Stack:** Cards that stick to the top and physically stack over each other.
- **Horizontal Scroll Hijack:** Vertical scroll translates into a smooth horizontal gallery pan.
- **Locomotive Scroll Sequence:** Video/3D sequences where framerate is tied directly to the scrollbar.
- **Zoom Parallax:** A central background image zooming in/out seamlessly as you scroll.
- **Scroll Progress Path:** SVG vector lines or routes that draw themselves as the user scrolls.
- **Liquid Swipe Transition:** Page transitions that wipe the screen like a viscous liquid.

### Galleries & Media

- **Dome Gallery:** A 3D gallery feeling like a panoramic dome.
- **Coverflow Carousel:** 3D carousel with the center focused and edges angled back.
- **Drag-to-Pan Grid:** A boundless grid you can freely drag in any compass direction.
- **Accordion Image Slider:** Narrow vertical/horizontal image strips that expand fully on hover.
- **Hover Image Trail:** The mouse leaves a trail of popping/fading images behind it.
- **Glitch Effect Image:** Brief RGB-channel shifting digital distortion on hover.

### Typography & Text

- **Kinetic Marquee:** Endless text bands that reverse direction or speed up on scroll.
- **Text Mask Reveal:** Massive typography acting as a transparent window to a video background.
- **Text Scramble Effect:** Matrix-style character decoding on load or hover.
- **Circular Text Path:** Text curved along a spinning circular path.
- **Gradient Stroke Animation:** Outlined text with a gradient continuously running along the stroke.
- **Kinetic Typography Grid:** A grid of letters dodging or rotating away from the cursor.

### Micro-Interactions & Effects

- **Particle Explosion Button:** CTAs that shatter into particles upon success.
- **Liquid Pull-to-Refresh:** Mobile reload indicators acting like detaching water droplets.
- **Skeleton Shimmer:** Shifting light reflections moving across placeholder boxes.
- **Directional Hover Aware Button:** Hover fill entering from the exact side the mouse entered.
- **Ripple Click Effect:** Visual waves rippling precisely from the click coordinates.
- **Animated SVG Line Drawing:** Vectors that draw their own contours in real-time.
- **Mesh Gradient Background:** Organic, lava-lamp-like animated color blobs.
- **Lens Blur Depth:** Dynamic focus blurring background UI layers to highlight a foreground action.

## 9. THE "MOTION-ENGINE" BENTO PARADIGM

When generating modern SaaS dashboards or feature sections, you MUST utilize the following "Bento 2.0" architecture and motion philosophy. This goes beyond static cards and enforces a "Vercel-core meets Dribbble-clean" aesthetic heavily reliant on perpetual physics — **at FULL tier only.** A Bento grid where every card loops forever is one of the most CPU-expensive patterns in this skill; it must always ship with the CORE/MINIMAL degradations below, not just as a nice-to-have.

### A. Core Design Philosophy

- **Aesthetic:** High-end, minimal, and functional.
- **Palette:** Background in `#f9fafb`. Cards are pure white (`#ffffff`) with a 1px border of `border-slate-200/50`.
- **Surfaces:** Use `rounded-[2.5rem]` for all major containers. Apply a "diffusion shadow" (a very light, wide-spreading shadow, e.g., `shadow-[0_20px_40px_-15px_rgba(0,0,0,0.05)]`) to create depth without clutter.
- **Typography:** Strict `Geist`, `Satoshi`, or `Cabinet Grotesk` font stack. Use subtle tracking (`tracking-tight`) for headers.
- **Labels:** Titles and descriptions must be placed **outside and below** the cards to maintain a clean, gallery-style presentation.
- **Pixel-Perfection:** Use generous `p-8` or `p-10` padding inside cards.

### B. The Animation Engine Specs (Perpetual Motion — FULL tier)

All cards must contain **"Perpetual Micro-Interactions"** on FULL tier. Use the following Framer Motion principles:

- **Spring Physics:** No linear easing. Use `type: "spring", stiffness: 100, damping: 20` for a premium, weighty feel.
- **Layout Transitions:** Heavily utilize the `layout` and `layoutId` props to ensure smooth re-ordering, resizing, and shared element state transitions.
- **Infinite Loops:** Every card must have an "Active State" that loops infinitely (Pulse, Typewriter, Float, or Carousel) to ensure the dashboard feels "alive" — capped at the concurrency limit from Section 4, even on FULL.
- **Performance:** Wrap dynamic lists in `<AnimatePresence>` and optimize for 60fps. **PERFORMANCE CRITICAL:** Any perpetual motion or infinite loop MUST be memoized (React.memo) and completely isolated in its own microscopic Client Component. Never trigger re-renders in the parent layout.
- **Pause off-screen:** Every infinitely-looping card must pause its animation when scrolled out of the viewport (`IntersectionObserver`) — a Bento grid is often taller than one screen, and there is no reason to keep animating cards nobody is looking at.

### C. Tiered fallback for the Bento Motion Engine

- **CORE tier:** Keep the layout, the data, and one-shot load-in fades. Replace every infinite loop with its resting/final frame — a typewriter effect becomes static final text, an auto-sorting list becomes a plain sorted list, a breathing status dot becomes a solid-colored one. Card hover/`:active` feedback (Rule 5, Section 3) stays.
- **MINIMAL tier:** Same as CORE, and additionally skip the `layout`/`layoutId` transition props — re-render the new state directly.

### D. The 5-Card Archetypes (Micro-Animation Specs, FULL tier)

Implement these specific micro-animations when constructing Bento grids (e.g., Row 1: 3 cols | Row 2: 2 cols split 70/30). Each has a named CORE-tier resting state per (C) above:

1. **The Intelligent List:** A vertical stack of items with an infinite auto-sorting loop. Items swap positions using `layoutId`, simulating an AI prioritizing tasks in real-time. _(CORE: static, correctly-sorted list.)_
2. **The Command Input:** A search/AI bar with a multi-step Typewriter Effect. It cycles through complex prompts, including a blinking cursor and a "processing" state with a shimmering loading gradient. _(CORE: one example prompt shown statically, cursor blink kept since it's cheap CSS.)_
3. **The Live Status:** A scheduling interface with "breathing" status indicators. Include a pop-up notification badge that emerges with an "Overshoot" spring effect, stays for 3 seconds, and vanishes. _(CORE: solid status dot, badge appears/disappears without the spring overshoot.)_
4. **The Wide Data Stream:** A horizontal "Infinite Carousel" of data cards or metrics. Ensure the loop is seamless (using `x: ["0%", "-100%"]`) with a speed that feels effortless. _(CORE: a static row with native horizontal scroll/swipe instead of an auto-playing loop.)_
5. **The Contextual UI (Focus Mode):** A document view that animates a staggered highlight of a text block, followed by a "Float-in" of a floating action toolbar with micro-icons. _(CORE: toolbar appears instantly, no stagger.)_

## 10. FINAL PRE-FLIGHT CHECK

Evaluate your code against this matrix before outputting. This is the **last** filter you apply to your logic.

- [ ] Is global state used appropriately to avoid deep prop-drilling rather than arbitrarily?
- [ ] Is mobile layout collapse (`w-full`, `px-4`, `max-w-7xl mx-auto`) guaranteed for high-variance designs?
- [ ] Do full-height sections safely use `min-h-[100dvh]` instead of the bugged `h-screen`?
- [ ] Do `useEffect` animations contain strict cleanup functions?
- [ ] Are empty, loading, and error states provided?
- [ ] Are cards omitted in favor of spacing where possible?
- [ ] Did you strictly isolate CPU-heavy perpetual animations in their own Client Components?
- [ ] Does every perpetual/infinite-loop or GSAP/ThreeJS component branch on device tier (Section 1B), with a real CORE/MINIMAL fallback rather than just the same animation slowed down?
- [ ] Is `prefers-reduced-motion` honored everywhere, independent of the hardware-based tier check?
- [ ] Are heavy motion libraries (GSAP, ThreeJS, non-core Framer Motion features) code-split so MINIMAL/CORE visitors don't download bytes for effects they'll never see?
- [ ] Do off-screen infinite-loop animations pause via `IntersectionObserver` rather than running continuously?
- [ ] Has the motion-heavy result been checked under CPU throttling (4x–6x), not just on the development machine?
